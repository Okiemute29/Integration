export const _logInUser = process.env.REACT_APP_BASE_URL + "/login"
