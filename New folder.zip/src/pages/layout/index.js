import RootLayout from "./Root.layout";

const PageLayouts = {RootLayout};

export default PageLayouts;