const _route = {
    _landing_page: '/',
    _about_us: '/about-us',
    _contact_us: '/contact-us',
    _login: '/login',
    _signup: '/signup',
    _register_otp: '/otp',
    _transaction_pin: '/set-transaction-pin',



    _dashboard: '/',
    _transfer: '/transfer',
    _transaction: '/transaction',
    _cardmangement: '/manage-card',
	_settings: "/settings",
    _not_found: '*',

}

export default _route